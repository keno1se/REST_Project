Start compodoc by this command in terminal:
npm run compodoc

Close compodoc:
Ctrl + c