import { TestBed } from '@angular/core/testing';

import { HttpServiceComponent } from './http.service';

describe('HttpService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: HttpServiceComponent = TestBed.get(HttpServiceComponent);
    expect(service).toBeTruthy();
  });
});
